Welcome to skippy-xd!

Skippy-xd is a lightweight, window-manager-agnostic window selector on the X server. With skippy-xd, you get live-preview on your alt-tab motions; you get the much coveted expose feature from Mac; you get a handy overview of all your virtual desktops in one glance with paging mode.

Switch is similar to Alt-Tab:

![](https://github.com/felixfung/skippy-xd-gifs/blob/main/switch.gif)

Expose is inspired from Mac:

![](https://github.com/felixfung/skippy-xd-gifs/blob/main/expose.gif)

Paging shows you your entire desktop:

![](https://github.com/felixfung/skippy-xd-gifs/blob/main/paging.gif)

If you are looking for a slick and minimalistic window selector that turns every of your little grrrrh throughout the day into a little bit of a yay, skippy-xd may be for you. If you agree with https://github.com/felixfung/skippy-xd/wiki/Skippy-xd-philosophy, then skippy-xd definitely is for you.

Check out the youtube videos:

[![Skippy-xd window selector!](https://img.youtube.com/vi/8zKAgt5mhek/mqdefault.jpg)](https://youtu.be/8zKAgt5mhek)
[![Skippy-xd window selector!](https://img.youtube.com/vi/6zEvYXWIQyg/mqdefault.jpg)](https://youtu.be/6zEvYXWIQyg)
[![Skippy-xd invocation methods!!](https://img.youtube.com/vi/sFvG9rcGanA/mqdefault.jpg)](https://youtu.be/sFvG9rcGanA)
[![Skippy-xd config file!](https://img.youtube.com/vi/Ct2pEx551TQ/mqdefault.jpg)](https://youtu.be/Ct2pEx551TQ)
[![Skippy-xd window selector pivoting!](https://img.youtube.com/vi/q9MjCVgDo2o/mqdefault.jpg)](https://youtu.be/q9MjCVgDo2o)
[![Skippy-xd exposé layout algorithm cosmos!](https://img.youtube.com/vi/c6EP6uyj3EA/mqdefault.jpg)](https://youtu.be/c6EP6uyj3EA)
[![Skippy-xd and tiling managers](https://img.youtube.com/vi/ENnxntTvWY4/mqdefault.jpg)](https://youtu.be/ENnxntTvWY4)
[![Skippy-xd and tiling managers](https://img.youtube.com/vi/CP2XZazIMlk/mqdefault.jpg)](https://youtu.be/CP2XZazIMlk)

skippy-xd works on anything X. See https://github.com/felixfung/skippy-xd/wiki/Adoption#compatible-desktop-environmentswindow-managers for details.

Installation and usage is simple:
```
git clone https://github.com/felixfung/skippy-xd.git
cd skippy-xd
make
make install

skippy-xd --start-daemon
skippy-xd --switch --next
skippy-xd --expose
skippy-xd --paging
```

Or better, find the package in your distro https://github.com/felixfung/skippy-xd/wiki/Adoption#distro-adoption, or find ready made package in https://github.com/felixfung/skippy-xd/releases/latest.

Check the wiki for documentation on basic use https://github.com/felixfung/skippy-xd/wiki/How-to-Use and advanced tips and tricks https://github.com/felixfung/skippy-xd/wiki/Advanced-Uses-and-Special-Set-Ups.

And please! If you share our love for skippy-xd, please do:

* Use it! Nothing is more rewarding to developers than widespread adoption of the app.
* Share it! Tell others about the app. Showcase screenshots and videos. Package it for your distros.
* Improve it! Make suggestions on feature improvements. Report bugs and they will be fixed. If you are a coder, start hacking!
